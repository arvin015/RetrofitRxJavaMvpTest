package com.arvin.demo.retrofitrxjavamvptest.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.arvin.demo.retrofitrxjavamvptest.R;
import com.arvin.demo.retrofitrxjavamvptest.adapter.DividerItemDecoration;
import com.arvin.demo.retrofitrxjavamvptest.adapter.HomeAdapter;
import com.arvin.demo.retrofitrxjavamvptest.base.BaseFragment;
import com.arvin.demo.retrofitrxjavamvptest.base.BasePressenter;
import com.arvin.demo.retrofitrxjavamvptest.pressenter.HomePressenter;
import com.arvin.demo.retrofitrxjavamvptest.view.IHomeView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by arvin on 2017/5/27.
 */

public class HomeFragment extends BaseFragment implements IHomeView {

    @BindView(R.id.homeRecycleView)
    RecyclerView homeRecycleView;
    Unbinder unbinder;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        initView();
    }

    private void initView() {

        String[] tests = new String[30];

        for (int i = 0; i < 30; i++) {
            tests[i] = "test" + (i + 1);
        }

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        homeRecycleView.setLayoutManager(layoutManager);

        HomeAdapter adapter = new HomeAdapter(getContext(), tests);
        homeRecycleView.setAdapter(adapter);

        homeRecycleView.addItemDecoration(new DividerItemDecoration(getContext(),
                DividerItemDecoration.VERTICAL_LIST));
    }

    @Override
    public int getLayoutId() {
        return R.layout.home;
    }

    @Override
    public BasePressenter createPressenter() {
        return new HomePressenter();
    }

    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO: inflate a fragment view
        View rootView = super.onCreateView(inflater, container, savedInstanceState);
        unbinder = ButterKnife.bind(this, rootView);
        return rootView;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
