package com.arvin.demo.retrofitrxjavamvptest.article;

import com.arvin.demo.retrofitrxjavamvptest.base.IBaseView;

/**
 * Created by arvin on 2017/5/24.
 */

public interface IAricleView extends IBaseView {

    void getAriticle(Article article);

}
