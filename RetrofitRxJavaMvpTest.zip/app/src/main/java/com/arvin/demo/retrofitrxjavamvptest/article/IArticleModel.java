package com.arvin.demo.retrofitrxjavamvptest.article;

/**
 * Created by arvin on 2017/5/24.
 */

public interface IArticleModel {

    void getArticle();
}
