package com.arvin.demo.retrofitrxjavamvptest.base;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import butterknife.ButterKnife;

/**
 * Created by arvin on 2017/5/27.
 */

public abstract class BaseFragment<V, P extends BasePressenter<V>> extends Fragment {

    private P pressenter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        pressenter = createPressenter();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(getLayoutId(), null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (pressenter != null) {
            pressenter.attach((V) this);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (pressenter != null) {
            pressenter.dettach();
        }
    }

    public abstract int getLayoutId();

    public abstract P createPressenter();
}
