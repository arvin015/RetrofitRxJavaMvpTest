package com.arvin.demo.retrofitrxjavamvptest.pressenter;

import com.arvin.demo.retrofitrxjavamvptest.base.BasePressenter;
import com.arvin.demo.retrofitrxjavamvptest.view.IBlogView;

/**
 * Created by arvin on 2017/5/27.
 */

public class BlogPressenter extends BasePressenter<IBlogView> {
}
