package com.arvin.demo.retrofitrxjavamvptest;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import com.arvin.demo.retrofitrxjavamvptest.Fragment.BlogFragment;
import com.arvin.demo.retrofitrxjavamvptest.Fragment.HomeFragment;
import com.arvin.demo.retrofitrxjavamvptest.Fragment.PhotoFragment;
import com.arvin.demo.retrofitrxjavamvptest.adapter.MainFragmentAdapter;
import com.arvin.demo.retrofitrxjavamvptest.base.BaseFragment;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.tool_bar)
    Toolbar toolBar;
    @BindView(R.id.tabLayout)
    TabLayout tabLayout;
    @BindView(R.id.viewPager)
    ViewPager viewPager;

    String[] titles = new String[] {"主页", "微博", "相册"};
    List<BaseFragment> fragments;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        initTabView();

//        showText.setText(Html.fromHtml("博客开始图片头部的显示效果就是这几行代码实现的。那么这里有几个属性我需要介绍一下：\n" +
//                "app:contentScrim=\"@color/colorPrimary\"表示当ImageView折叠后Toolbar的颜色，这里的颜色我们不可以直接在Toolbar中设置，因为Toolbar一开始是透明的，只有当ImageView折叠到Toolbar的高度时Toolbar才变为蓝色的。\n" +
//                "app:layout_scrollFlags是一个非常重要的属性，它里边的取值主要有五种，下面我分别来解释：\n" +
//                "        1.scroll 表示CollapsingToolbarLayout可以滚动（不设置的话头部的ImageView将不能折叠）\n" +
//                "        2.enterAlways 表示底部的滚动控件只要向下滚动，头部就显示出来\n" +
//                "        3.enterAlwaysCollapsed 表示当底部滚动控件滚动见顶时，头部显示出来\n" +
//                "        4.exitUntilCollapsed 表示头部折叠到最小高度时（Toolbar的高度），就不再折叠\n" +
//                "        5.snap 表示在滑动过程中如果停止滑动，则头部会就近折叠（要么恢复原状，要么折叠成一个Toolbar）"));

//        Intent intent = new Intent();
//        intent.setClass(this, ArticleActivity.class);
//        this.startActivity(intent);

//        finish();
    }

    private void initTabView() {
        fragments = new ArrayList<>();
        fragments.add(new HomeFragment());
        fragments.add(new BlogFragment());
        fragments.add(new PhotoFragment());

        viewPager.setAdapter(new MainFragmentAdapter(getSupportFragmentManager(), fragments, titles));
        tabLayout.setupWithViewPager(viewPager);
    }
}
