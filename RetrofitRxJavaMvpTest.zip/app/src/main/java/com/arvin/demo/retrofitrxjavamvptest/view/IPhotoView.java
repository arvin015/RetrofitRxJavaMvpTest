package com.arvin.demo.retrofitrxjavamvptest.view;

import com.arvin.demo.retrofitrxjavamvptest.base.IBaseView;

/**
 * Created by arvin on 2017/5/27.
 */

public interface IPhotoView extends IBaseView {
}
